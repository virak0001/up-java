package mypackage;

public class Main {

	public static void main(String[] args) {
		
		Manager manager = new Manager("virak", 1, 2000);
		System.out.println(manager.annaulPay());

	}

}
